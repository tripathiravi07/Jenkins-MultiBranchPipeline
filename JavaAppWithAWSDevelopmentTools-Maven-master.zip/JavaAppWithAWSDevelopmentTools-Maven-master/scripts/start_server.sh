#!/bin/bash
sudo su
tomcatup