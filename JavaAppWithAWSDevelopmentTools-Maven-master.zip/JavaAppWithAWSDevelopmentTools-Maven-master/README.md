# JavaAppWithAWSDevelopmentTools-UsingMaven
Code is stored in CodeCommit,
In this project i have used codebuild with maven for building code and code deploy for deployment.,
Codepipeline is used for orchestration of above tools.
